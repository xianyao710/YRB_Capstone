#this directory contains all the needed scripts for the workflow and a sample data set in Homer format.
#MEME suite is pre-required to be installed, and the enviromental path for program `tomtom` should be added.
#motif2meme.R is the R script to convert motif into meme format
#GetCluster.py takes 1,2 column of tomtomt output to extract connected components
#extract`_`cluster.py produce motif meme format file given the motif names
#MotifReduce.pl generates consensus motifs
